Place your custom fonts here!
If your font is named "amogus.ttf", you can make lua texts use it with the following:

setTextFont("yourObjectTag", "amogus.ttf");