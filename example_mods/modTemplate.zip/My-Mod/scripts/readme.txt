Add .lua scripts here!
Lua scripts in this folder will be loaded on all songs, no matter the difficulty, song name, week or anything.

If you've put it inside a modpack, as long as the modpack is loaded, the script will be running.